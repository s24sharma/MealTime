package com.sasha.myapplication

data class Restaurant (
    var id: Int,
    var name:String,
    var rating: String,
    var cost_for_one: Int,
    var image_url:String
    )