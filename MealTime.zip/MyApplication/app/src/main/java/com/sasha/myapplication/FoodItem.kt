package com.sasha.myapplication

 data class FoodItem (

         var id:String?,
         var name:String?,
         var cost_for_one: Int?,
         var restaurant_id:String?



     )
